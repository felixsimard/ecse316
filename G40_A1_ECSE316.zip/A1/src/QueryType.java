public enum QueryType {
   A,
   MX,
   NS,
   CNAME,
   OTHER
}
